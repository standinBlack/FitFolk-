# FitFolk

Fitness built around you. A free, offline-first coaching app that builds a personal workout plan from your profile, goals, time, equipment, and a short fitness check.

## Stack

- React 18 + Vite
- React Router
- Context API
- IndexedDB (`idb`)
- Framer Motion
- PWA (vite-plugin-pwa, Workbox)

No backend. All data stays on the device.

## Run locally

```bash
cd fitfolk
npm install
npm run dev
```

Open the printed local URL (default `http://localhost:5173`).

## Production build

```bash
npm run build
npm run preview
```

The production build is installable (manifest + service worker) and works offline after the first visit.

## Android later

This project is structured as a mobile-first PWA. To wrap it with Capacitor:

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init FitFolk com.fitfolk.app --web-dir dist
npm run build
npx cap add android
npx cap copy
npx cap open android
```

## Features

- Splash → welcome → questionnaire → assessment → generated plan
- Dashboard with streak, weekly completion, and quick-start
- Guided workout player with timer, sets, skip, and finish
- Exercise library with looping SVG movement demos
- Progress measurements, charts, and local body photos
- Calendar with completed / missed days
- Music player that keeps running during sessions (built-in tones + local MP3s)
- Settings: dark mode, units, notification prefs, export, reset

## Data

IndexedDB database `fitfolk-db` stores profile, plan, sessions, measurements, photos, music blobs, and settings.
