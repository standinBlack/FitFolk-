import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  STORE,
  exportAllData,
  idbDelete,
  idbGet,
  idbGetAll,
  idbPut,
  idbSet,
  resetAllData,
} from '../db/indexedDB';
import { generatePlan, flattenDays } from '../data/planGenerator';
import { calcStreak, todayISO } from '../utils/dates';

const AppContext = createContext(null);

const defaultSettings = {
  darkMode: true,
  units: 'kg',
  notifications: {
    workoutReminders: true,
    streakAlerts: true,
    weeklySummary: false,
  },
};

export function AppProvider({ children }) {
  const [ready, setReady] = useState(false);
  const [profile, setProfile] = useState(null);
  const [plan, setPlan] = useState(null);
  const [sessions, setSessions] = useState([]);
  const [measurements, setMeasurements] = useState([]);
  const [photos, setPhotos] = useState([]);
  const [settings, setSettings] = useState(defaultSettings);
  const [draft, setDraft] = useState({});

  useEffect(() => {
    let alive = true;
    (async () => {
      const [p, pl, sess, meas, ph, st] = await Promise.all([
        idbGet(STORE.PROFILE, 'current'),
        idbGet(STORE.PLAN, 'current'),
        idbGetAll(STORE.SESSIONS),
        idbGetAll(STORE.MEASUREMENTS),
        idbGetAll(STORE.PHOTOS),
        idbGet(STORE.SETTINGS, 'current'),
      ]);
      if (!alive) return;
      setProfile(p || null);
      setPlan(pl || null);
      setSessions(sess || []);
      setMeasurements(meas || []);
      setPhotos(ph || []);
      setSettings({ ...defaultSettings, ...(st || {}) });
      setReady(true);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const saveProfile = useCallback(async (next) => {
    const merged = { ...next, updatedAt: new Date().toISOString() };
    setProfile(merged);
    await idbSet(STORE.PROFILE, 'current', merged);
    return merged;
  }, []);

  const saveSettings = useCallback(async (next) => {
    const merged = { ...defaultSettings, ...next };
    setSettings(merged);
    await idbSet(STORE.SETTINGS, 'current', merged);
  }, []);

  const createPlanFromProfile = useCallback(async (userProfile) => {
    const generated = generatePlan(userProfile);
    setPlan(generated);
    await idbSet(STORE.PLAN, 'current', generated);
    return generated;
  }, []);

  const completeOnboarding = useCallback(
    async (answers) => {
      const user = {
        ...answers,
        onboardingComplete: true,
        createdAt: answers.createdAt || new Date().toISOString(),
      };
      await saveProfile(user);
      await createPlanFromProfile(user);
      return user;
    },
    [createPlanFromProfile, saveProfile],
  );

  const logSession = useCallback(async (payload) => {
    const session = {
      id: `${Date.now()}`,
      date: payload.date || todayISO(),
      dayId: payload.dayId,
      title: payload.title,
      durationSec: payload.durationSec || 0,
      exercisesDone: payload.exercisesDone || 0,
      skipped: payload.skipped || false,
    };
    setSessions((prev) => [...prev, session]);
    await idbPut(STORE.SESSIONS, session);

    if (plan && payload.dayId) {
      const next = {
        ...plan,
        weeks: plan.weeks.map((w) => ({
          ...w,
          days: w.days.map((d) => (d.id === payload.dayId ? { ...d, completed: true, completedOn: session.date } : d)),
        })),
      };
      setPlan(next);
      await idbSet(STORE.PLAN, 'current', next);
    }
    return session;
  }, [plan]);

  const addMeasurement = useCallback(async (entry) => {
    const item = {
      id: `${Date.now()}`,
      date: entry.date || todayISO(),
      weight: entry.weight === '' ? null : Number(entry.weight),
      waist: entry.waist === '' ? null : Number(entry.waist),
      chest: entry.chest === '' ? null : Number(entry.chest),
      arm: entry.arm === '' ? null : Number(entry.arm),
    };
    setMeasurements((prev) => [...prev, item].sort((a, b) => a.date.localeCompare(b.date)));
    await idbPut(STORE.MEASUREMENTS, item);
    if (item.weight && profile) {
      await saveProfile({ ...profile, weight: item.weight });
    }
    return item;
  }, [profile, saveProfile]);

  const addPhoto = useCallback(async (file) => {
    const item = {
      id: `${Date.now()}`,
      date: todayISO(),
      name: file.name,
      type: file.type,
      blob: file,
    };
    setPhotos((prev) => [...prev, item]);
    await idbPut(STORE.PHOTOS, item);
    return item;
  }, []);

  const removePhoto = useCallback(async (id) => {
    setPhotos((prev) => prev.filter((p) => p.id !== id));
    await idbDelete(STORE.PHOTOS, id);
  }, []);

  const resetProgress = useCallback(async () => {
    await resetAllData();
    setProfile(null);
    setPlan(null);
    setSessions([]);
    setMeasurements([]);
    setPhotos([]);
    setSettings(defaultSettings);
    setDraft({});
    await idbSet(STORE.SETTINGS, 'current', defaultSettings);
  }, []);

  const exportData = useCallback(async () => exportAllData(), []);

  const completedDates = useMemo(
    () => [...new Set(sessions.filter((s) => !s.skipped).map((s) => s.date))],
    [sessions],
  );

  const streak = useMemo(() => calcStreak(completedDates), [completedDates]);

  const days = useMemo(() => flattenDays(plan), [plan]);

  const todayWorkout = useMemo(() => {
    if (!days.length) return null;
    const completedIds = new Set(days.filter((d) => d.completed).map((d) => d.id));
    return days.find((d) => !completedIds.has(d.id)) || days[days.length - 1];
  }, [days]);

  const completionPct = useMemo(() => {
    if (!days.length) return 0;
    const done = days.filter((d) => d.completed).length;
    return Math.round((done / days.length) * 100);
  }, [days]);

  const value = useMemo(
    () => ({
      ready,
      profile,
      plan,
      sessions,
      measurements,
      photos,
      settings,
      draft,
      setDraft,
      saveProfile,
      saveSettings,
      completeOnboarding,
      createPlanFromProfile,
      logSession,
      addMeasurement,
      addPhoto,
      removePhoto,
      resetProgress,
      exportData,
      completedDates,
      streak,
      days,
      todayWorkout,
      completionPct,
    }),
    [
      ready,
      profile,
      plan,
      sessions,
      measurements,
      photos,
      settings,
      draft,
      saveProfile,
      saveSettings,
      completeOnboarding,
      createPlanFromProfile,
      logSession,
      addMeasurement,
      addPhoto,
      removePhoto,
      resetProgress,
      exportData,
      completedDates,
      streak,
      days,
      todayWorkout,
      completionPct,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
