import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { STORE, idbDelete, idbGetAll, idbPut } from '../db/indexedDB';

const MusicContext = createContext(null);

const BUILTIN = [
  { id: 'builtin-pulse', title: 'Pulse Drive', artist: 'FitFolk Radio', builtin: true, bpm: 128 },
  { id: 'builtin-climb', title: 'Steady Climb', artist: 'FitFolk Radio', builtin: true, bpm: 110 },
  { id: 'builtin-spark', title: 'Green Spark', artist: 'FitFolk Radio', builtin: true, bpm: 140 },
  { id: 'builtin-flow', title: 'Easy Flow', artist: 'FitFolk Radio', builtin: true, bpm: 96 },
];

function toneUrl(freq, seconds = 8) {
  const sampleRate = 22050;
  const length = sampleRate * seconds;
  const buffer = new ArrayBuffer(44 + length * 2);
  const view = new DataView(buffer);
  const writeStr = (offset, str) => {
    for (let i = 0; i < str.length; i += 1) view.setUint8(offset + i, str.charCodeAt(i));
  };
  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + length * 2, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, length * 2, true);
  for (let i = 0; i < length; i += 1) {
    const t = i / sampleRate;
    const env = Math.min(1, t * 4) * Math.min(1, (seconds - t) * 2);
    const osc =
      0.45 * Math.sin(2 * Math.PI * freq * t) +
      0.22 * Math.sin(2 * Math.PI * (freq * 1.5) * t) +
      0.12 * Math.sin(2 * Math.PI * (freq * 2) * t);
    const sample = osc * env * 0.35;
    view.setInt16(44 + i * 2, sample * 32767, true);
  }
  const blob = new Blob([buffer], { type: 'audio/wav' });
  return URL.createObjectURL(blob);
}

export function MusicProvider({ children }) {
  const audioRef = useRef(null);
  const urlsRef = useRef({});
  const [tracks, setTracks] = useState(BUILTIN);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState('all');
  const [volume, setVolume] = useState(0.7);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    const freqs = { 'builtin-pulse': 220, 'builtin-climb': 174, 'builtin-spark': 262, 'builtin-flow': 196 };
    BUILTIN.forEach((t) => {
      urlsRef.current[t.id] = toneUrl(freqs[t.id], 10);
    });
    (async () => {
      const stored = await idbGetAll(STORE.MUSIC);
      const hydrated = stored.map((t) => {
        const url = URL.createObjectURL(t.blob);
        urlsRef.current[t.id] = url;
        return { id: t.id, title: t.title, artist: t.artist || 'You', builtin: false };
      });
      if (hydrated.length) setTracks((prev) => [...prev, ...hydrated]);
    })();
    return () => {
      Object.values(urlsRef.current).forEach((u) => URL.revokeObjectURL(u));
    };
  }, []);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return undefined;
    audio.volume = volume;
    const onTime = () => {
      setProgress(audio.currentTime);
      setDuration(audio.duration || 0);
    };
    const onEnded = () => {
      if (repeat === 'one') {
        audio.currentTime = 0;
        audio.play();
        return;
      }
      next(true);
    };
    audio.addEventListener('timeupdate', onTime);
    audio.addEventListener('ended', onEnded);
    return () => {
      audio.removeEventListener('timeupdate', onTime);
      audio.removeEventListener('ended', onEnded);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [repeat, tracks, index, shuffle]);

  const current = tracks[index] || tracks[0];

  const loadAndPlay = (i, autoplay = true) => {
    const audio = audioRef.current;
    const track = tracks[i];
    if (!audio || !track) return;
    audio.src = urlsRef.current[track.id] || '';
    audio.volume = volume;
    setIndex(i);
    if (autoplay) {
      audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
  };

  const play = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!audio.src && current) audio.src = urlsRef.current[current.id] || '';
    audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  };

  const pause = () => {
    audioRef.current?.pause();
    setPlaying(false);
  };

  const next = (fromEnded = false) => {
    if (!tracks.length) return;
    let n;
    if (shuffle) n = Math.floor(Math.random() * tracks.length);
    else n = (index + 1) % tracks.length;
    if (!fromEnded && repeat === 'one') n = index;
    loadAndPlay(n, true);
  };

  const prev = () => {
    if (!tracks.length) return;
    const n = (index - 1 + tracks.length) % tracks.length;
    loadAndPlay(n, true);
  };

  const seek = (t) => {
    if (audioRef.current) audioRef.current.currentTime = t;
  };

  const changeVolume = (v) => {
    const val = Math.min(1, Math.max(0, Number(v)));
    setVolume(val);
    if (audioRef.current) audioRef.current.volume = val;
  };

  const addFiles = async (fileList) => {
    const files = Array.from(fileList || []).filter((f) => /audio\//.test(f.type) || /\.mp3$/i.test(f.name));
    const added = [];
    for (const file of files) {
      const item = {
        id: `local-${Date.now()}-${file.name}`,
        title: file.name.replace(/\.(mp3|wav|m4a|ogg)$/i, ''),
        artist: 'My Playlist',
        blob: file,
      };
      await idbPut(STORE.MUSIC, item);
      const url = URL.createObjectURL(file);
      urlsRef.current[item.id] = url;
      added.push({ id: item.id, title: item.title, artist: item.artist, builtin: false });
    }
    if (added.length) setTracks((prev) => [...prev, ...added]);
  };

  const removeTrack = async (id) => {
    const track = tracks.find((t) => t.id === id);
    if (!track || track.builtin) return;
    if (urlsRef.current[id]) {
      URL.revokeObjectURL(urlsRef.current[id]);
      delete urlsRef.current[id];
    }
    await idbDelete(STORE.MUSIC, id);
    setTracks((prev) => {
      const nextTracks = prev.filter((t) => t.id !== id);
      if (current?.id === id) {
        setTimeout(() => loadAndPlay(0, playing), 0);
      }
      return nextTracks;
    });
  };

  const value = useMemo(
    () => ({
      tracks,
      current,
      playing,
      shuffle,
      repeat,
      volume,
      progress,
      duration,
      play,
      pause,
      next,
      prev,
      seek,
      changeVolume,
      setShuffle,
      setRepeat,
      addFiles,
      removeTrack,
      playTrack: (id) => {
        const i = tracks.findIndex((t) => t.id === id);
        if (i >= 0) loadAndPlay(i, true);
      },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tracks, current, playing, shuffle, repeat, volume, progress, duration, index],
  );

  return (
    <MusicContext.Provider value={value}>
      <audio ref={audioRef} preload="auto" />
      {children}
    </MusicContext.Provider>
  );
}

export function useMusic() {
  const ctx = useContext(MusicContext);
  if (!ctx) throw new Error('useMusic must be used within MusicProvider');
  return ctx;
}
