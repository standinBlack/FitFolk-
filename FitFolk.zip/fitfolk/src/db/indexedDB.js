import { openDB } from 'idb';

const DB_NAME = 'fitfolk-db';
const DB_VERSION = 1;

export const STORE = {
  PROFILE: 'profile',
  PLAN: 'plan',
  SESSIONS: 'sessions',
  MEASUREMENTS: 'measurements',
  PHOTOS: 'photos',
  MUSIC: 'music',
  SETTINGS: 'settings',
};

export function openFitFolkDB() {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE.PROFILE)) {
        db.createObjectStore(STORE.PROFILE);
      }
      if (!db.objectStoreNames.contains(STORE.PLAN)) {
        db.createObjectStore(STORE.PLAN);
      }
      if (!db.objectStoreNames.contains(STORE.SESSIONS)) {
        const s = db.createObjectStore(STORE.SESSIONS, { keyPath: 'id' });
        s.createIndex('byDate', 'date');
      }
      if (!db.objectStoreNames.contains(STORE.MEASUREMENTS)) {
        const m = db.createObjectStore(STORE.MEASUREMENTS, { keyPath: 'id' });
        m.createIndex('byDate', 'date');
      }
      if (!db.objectStoreNames.contains(STORE.PHOTOS)) {
        const p = db.createObjectStore(STORE.PHOTOS, { keyPath: 'id' });
        p.createIndex('byDate', 'date');
      }
      if (!db.objectStoreNames.contains(STORE.MUSIC)) {
        db.createObjectStore(STORE.MUSIC, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE.SETTINGS)) {
        db.createObjectStore(STORE.SETTINGS);
      }
    },
  });
}

export async function idbGet(store, key) {
  const db = await openFitFolkDB();
  return db.get(store, key);
}

export async function idbSet(store, key, value) {
  const db = await openFitFolkDB();
  return db.put(store, value, key);
}

export async function idbPut(store, value) {
  const db = await openFitFolkDB();
  return db.put(store, value);
}

export async function idbGetAll(store) {
  const db = await openFitFolkDB();
  return db.getAll(store);
}

export async function idbDelete(store, key) {
  const db = await openFitFolkDB();
  return db.delete(store, key);
}

export async function idbClear(store) {
  const db = await openFitFolkDB();
  return db.clear(store);
}

export async function resetAllData() {
  const db = await openFitFolkDB();
  await Promise.all(Object.values(STORE).map((s) => db.clear(s)));
}

export async function exportAllData() {
  const db = await openFitFolkDB();
  const data = {};
  for (const store of Object.values(STORE)) {
    if (store === STORE.PHOTOS || store === STORE.MUSIC) {
      const items = await db.getAll(store);
      data[store] = items.map((item) => {
        const copy = { ...item };
        delete copy.blob;
        return copy;
      });
    } else if (store === STORE.PROFILE || store === STORE.PLAN || store === STORE.SETTINGS) {
      data[store] = await db.get(store, 'current');
    } else {
      data[store] = await db.getAll(store);
    }
  }
  return data;
}
