import { useEffect } from 'react';
import { Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { useApp } from './context/AppContext';
import BottomNav from './components/BottomNav';
import Splash from './pages/Splash';
import Welcome from './pages/Welcome';
import Onboarding from './pages/Onboarding';
import Assessment from './pages/Assessment';
import Generating from './pages/Generating';
import Dashboard from './pages/Dashboard';
import Workout from './pages/Workout';
import Library from './pages/Library';
import ExerciseDetail from './pages/ExerciseDetail';
import Progress from './pages/Progress';
import CalendarPage from './pages/CalendarPage';
import Music from './pages/Music';
import Settings from './pages/Settings';

function ThemeSync() {
  const { settings } = useApp();
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.darkMode ? 'dark' : 'light');
  }, [settings.darkMode]);
  return null;
}

function AppShell() {
  return (
    <div className="app-shell">
      <Outlet />
      <BottomNav />
    </div>
  );
}

function Guard({ children }) {
  const { ready, profile } = useApp();
  if (!ready) return <Splash />;
  if (!profile?.onboardingComplete) return <Navigate to="/welcome" replace />;
  return children;
}

function PublicOnly({ children }) {
  const { ready, profile } = useApp();
  if (!ready) return <Splash />;
  if (profile?.onboardingComplete) return <Navigate to="/app" replace />;
  return children;
}

export default function App() {
  const location = useLocation();
  return (
    <>
      <ThemeSync />
      <AnimatePresence mode="wait">
        <motion.div key={location.pathname} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
          <Routes location={location}>
            <Route path="/" element={<Splash />} />
            <Route path="/welcome" element={<PublicOnly><Welcome /></PublicOnly>} />
            <Route path="/onboarding" element={<Onboarding />} />
            <Route path="/assessment" element={<Assessment />} />
            <Route path="/generating" element={<Generating />} />
            <Route
              path="/app"
              element={(
                <Guard>
                  <AppShell />
                </Guard>
              )}
            >
              <Route index element={<Dashboard />} />
              <Route path="workout/:dayId" element={<Workout />} />
              <Route path="library" element={<Library />} />
              <Route path="library/:id" element={<ExerciseDetail />} />
              <Route path="progress" element={<Progress />} />
              <Route path="calendar" element={<CalendarPage />} />
              <Route path="music" element={<Music />} />
              <Route path="settings" element={<Settings />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </motion.div>
      </AnimatePresence>
    </>
  );
}
