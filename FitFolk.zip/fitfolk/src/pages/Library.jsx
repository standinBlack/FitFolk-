import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CATEGORIES, EXERCISES } from '../data/exercises';
import ExerciseAnimation from '../components/ExerciseAnimation';

export default function Library() {
  const [cat, setCat] = useState('Abs');
  const list = useMemo(() => EXERCISES.filter((e) => e.category === cat), [cat]);

  return (
    <div className="page">
      <p className="eyebrow">Moves</p>
      <h1>Exercise library</h1>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 8 }}>
        {CATEGORIES.map((c) => (
          <button key={c} className={`chip${cat === c ? ' active' : ''}`} style={{ minWidth: 96 }} onClick={() => setCat(c)}>
            {c}
          </button>
        ))}
      </div>
      <div className="card">
        {list.map((ex) => (
          <Link key={ex.id} to={`/app/library/${ex.id}`} className="list-row">
            <div style={{ width: 56, height: 56, flexShrink: 0 }}>
              <ExerciseAnimation exerciseId={ex.id} compact title={ex.name} />
            </div>
            <div style={{ flex: 1 }}>
              <strong>{ex.name}</strong>
              <div style={{ color: 'var(--muted)', fontSize: 13 }}>{ex.muscles.join(' · ')}</div>
            </div>
            <span className="badge">{ex.difficulty}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
