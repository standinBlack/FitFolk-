import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const PUSH = ['0–5', '6–15', '16–30', '30+'];
const PLANK = ['Under 15 seconds', '15–30 seconds', '30–60 seconds', '60+ seconds'];
const SQUAT = ['0–10', '11–25', '26–50', '50+'];

export default function Assessment() {
  const nav = useNavigate();
  const { draft, setDraft } = useApp();
  const [pushups, setPushups] = useState(draft.assessment?.pushups || '');
  const [plank, setPlank] = useState(draft.assessment?.plank || '');
  const [squats, setSquats] = useState(draft.assessment?.squats || '');

  const save = () => {
    setDraft({
      ...draft,
      assessment: { pushups, plank, squats },
    });
    nav('/generating');
  };

  return (
    <div className="page">
      <p className="eyebrow">Fitness check</p>
      <h1>Quick assessment</h1>
      <p>Answer honestly. This sets starting volume, not a grade.</p>

      <div className="card">
        <h3>Push-Ups</h3>
        <p>How many can you perform with good form?</p>
        <div className="chip-grid">
          {PUSH.map((v) => (
            <button key={v} className={`chip${pushups === v ? ' active' : ''}`} onClick={() => setPushups(v)}>{v}</button>
          ))}
        </div>
      </div>
      <div className="card">
        <h3>Plank Hold</h3>
        <p>Longest clean hold.</p>
        <div className="chip-grid">
          {PLANK.map((v) => (
            <button key={v} className={`chip blue${plank === v ? ' active' : ''}`} onClick={() => setPlank(v)}>{v}</button>
          ))}
        </div>
      </div>
      <div className="card">
        <h3>Squats</h3>
        <p>Bodyweight squats to a comfortable depth.</p>
        <div className="chip-grid">
          {SQUAT.map((v) => (
            <button key={v} className={`chip${squats === v ? ' active' : ''}`} onClick={() => setSquats(v)}>{v}</button>
          ))}
        </div>
      </div>

      <div className="btn-row" style={{ marginTop: 18 }}>
        <button className="btn btn-ghost" onClick={() => nav('/onboarding')}>Back</button>
        <button className="btn btn-primary" disabled={!pushups || !plank || !squats} onClick={save}>Build my plan</button>
      </div>
    </div>
  );
}
