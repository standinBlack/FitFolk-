import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';

const LINES = [
  'Reading your profile…',
  'Matching exercises to your equipment…',
  'Scaling volume from your assessment…',
  'Laying out a weekly rhythm…',
  'Adding progressive overload…',
];

export default function Generating() {
  const nav = useNavigate();
  const { draft, completeOnboarding } = useApp();
  const [i, setI] = useState(0);

  useEffect(() => {
    const tick = setInterval(() => setI((n) => Math.min(n + 1, LINES.length - 1)), 700);
    const run = async () => {
      await completeOnboarding(draft);
      setTimeout(() => nav('/app', { replace: true }), 2800);
    };
    run();
    return () => clearInterval(tick);
  }, [completeOnboarding, draft, nav]);

  return (
    <div className="splash">
      <div className="loader" />
      <h1 style={{ fontSize: 28 }}>Designing your plan</h1>
      <motion.p key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}>
        {LINES[i]}
      </motion.p>
    </div>
  );
}
