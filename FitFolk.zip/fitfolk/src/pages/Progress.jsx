import { useEffect, useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import LineChart from '../components/LineChart';

export default function Progress() {
  const { measurements, addMeasurement, photos, addPhoto, removePhoto, streak, completionPct, sessions, settings } = useApp();
  const [form, setForm] = useState({ weight: '', waist: '', chest: '', arm: '' });
  const [urls, setUrls] = useState([]);
  const unit = settings.units === 'lbs' ? 'lbs / in' : 'kg / cm';

  const series = useMemo(() => ({
    weight: measurements.map((m) => m.weight),
    waist: measurements.map((m) => m.waist),
  }), [measurements]);

  useEffect(() => {
    const next = photos.map((p) => ({ id: p.id, date: p.date, url: URL.createObjectURL(p.blob) }));
    setUrls(next);
    return () => next.forEach((p) => URL.revokeObjectURL(p.url));
  }, [photos]);

  return (
    <div className="page">
      <p className="eyebrow">Tracking</p>
      <h1>Progress</h1>
      <div className="stat-grid">
        <div className="stat"><b>{streak}</b><span>Current streak</span></div>
        <div className="stat"><b>{completionPct}%</b><span>Goal completion</span></div>
        <div className="stat"><b>{sessions.length}</b><span>Workouts logged</span></div>
        <div className="stat"><b>{measurements.length}</b><span>Check-ins</span></div>
      </div>

      <div className="card">
        <h3>Log measurements ({unit})</h3>
        {['weight', 'waist', 'chest', 'arm'].map((k) => (
          <div className="field" key={k}>
            <label htmlFor={k}>{k}</label>
            <input id={k} type="number" value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
          </div>
        ))}
        <button className="btn btn-primary" onClick={() => { addMeasurement(form); setForm({ weight: '', waist: '', chest: '', arm: '' }); }}>
          Save check-in
        </button>
      </div>

      <div className="card">
        <h3>Weight trend</h3>
        <LineChart points={series.weight} />
      </div>
      <div className="card">
        <h3>Waist trend</h3>
        <LineChart points={series.waist} color="#4c8dff" />
      </div>

      <div className="card">
        <h3>Body progress photos</h3>
        <p>Saved only on this device.</p>
        <input
          type="file"
          accept="image/*"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) addPhoto(file);
            e.target.value = '';
          }}
        />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 12 }}>
          {urls.map((p) => (
            <div key={p.id} style={{ position: 'relative' }}>
              <img src={p.url} alt={`Progress from ${p.date}`} style={{ width: '100%', height: 110, objectFit: 'cover', borderRadius: 12 }} />
              <button className="btn btn-danger" style={{ position: 'absolute', top: 4, right: 4, padding: '4px 8px', width: 'auto' }} onClick={() => removePhoto(p.id)}>
                ×
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
