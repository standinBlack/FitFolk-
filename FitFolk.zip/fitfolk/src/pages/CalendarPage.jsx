import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { monthMatrix, todayISO } from '../utils/dates';

export default function CalendarPage() {
  const { completedDates, streak } = useApp();
  const now = new Date();
  const [cursor, setCursor] = useState({ y: now.getFullYear(), m: now.getMonth() });
  const cells = useMemo(() => monthMatrix(cursor.y, cursor.m), [cursor]);
  const today = todayISO();
  const title = new Date(cursor.y, cursor.m, 1).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  const doneSet = new Set(completedDates);

  return (
    <div className="page">
      <p className="eyebrow">Consistency</p>
      <div className="topbar">
        <h1 style={{ fontSize: 28 }}>{title}</h1>
        <span className="badge">{streak} streak</span>
      </div>
      <div className="btn-row" style={{ marginBottom: 12 }}>
        <button className="btn btn-ghost" onClick={() => setCursor((c) => (c.m === 0 ? { y: c.y - 1, m: 11 } : { y: c.y, m: c.m - 1 }))}>Prev</button>
        <button className="btn btn-ghost" onClick={() => setCursor((c) => (c.m === 11 ? { y: c.y + 1, m: 0 } : { y: c.y, m: c.m + 1 }))}>Next</button>
      </div>
      <div className="cal-grid" style={{ marginBottom: 6 }}>
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
          <div key={i} className="cal-label">{d}</div>
        ))}
      </div>
      <div className="cal-grid">
        {cells.map((iso, i) => {
          if (!iso) return <div key={i} />;
          const done = doneSet.has(iso);
          const miss = iso < today && !done;
          return (
            <div key={iso} className={`week-cell${done ? ' done' : ''}${miss ? ' miss' : ''}${iso === today ? ' today' : ''}`}>
              {Number(iso.slice(-2))}
            </div>
          );
        })}
      </div>
      <div className="card">
        <p style={{ margin: 0 }}>Green days are completed workouts. Red-tinted days before today were missed. Blue outline is today.</p>
      </div>
    </div>
  );
}
