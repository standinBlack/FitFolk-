import { useNavigate, useParams } from 'react-router-dom';
import { getExercise } from '../data/exercises';
import ExerciseAnimation from '../components/ExerciseAnimation';

export default function ExerciseDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const ex = getExercise(id);
  if (!ex) {
    return (
      <div className="page">
        <h1>Not found</h1>
        <button className="btn btn-primary" onClick={() => nav('/app/library')}>Back</button>
      </div>
    );
  }
  return (
    <div className="page">
      <button className="btn btn-ghost" style={{ width: 'auto', marginBottom: 12 }} onClick={() => nav(-1)}>Back</button>
      <p className="eyebrow">{ex.category}</p>
      <h1>{ex.name}</h1>
      <ExerciseAnimation exerciseId={ex.id} title={ex.name} />
      <div className="card" style={{ marginTop: 12 }}>
        <p>{ex.description}</p>
        <p><strong>Muscles:</strong> {ex.muscles.join(', ')}</p>
        <p><strong>Difficulty:</strong> {ex.difficulty}</p>
        <p><strong>Equipment:</strong> {ex.equipment.join(', ')}</p>
        {ex.cues && (
          <ul>
            {ex.cues.map((c) => (
              <li key={c}>{c}</li>
            ))}
          </ul>
        )}
        <p className="eyebrow">Looping movement demo</p>
      </div>
    </div>
  );
}
