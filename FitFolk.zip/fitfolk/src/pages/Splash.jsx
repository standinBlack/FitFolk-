import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import Logo from '../components/Logo';

export default function Splash() {
  const nav = useNavigate();
  const { ready, profile } = useApp();

  useEffect(() => {
    if (!ready) return undefined;
    const t = setTimeout(() => {
      if (profile?.onboardingComplete) nav('/app', { replace: true });
      else nav('/welcome', { replace: true });
    }, 1600);
    return () => clearTimeout(t);
  }, [ready, profile, nav]);

  return (
    <div className="splash">
      <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5 }}>
        <Logo size={56} />
      </motion.div>
      <motion.p initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.25 }}>
        Fitness built around you.
      </motion.p>
      <div className="loader" aria-label="Loading" />
    </div>
  );
}
