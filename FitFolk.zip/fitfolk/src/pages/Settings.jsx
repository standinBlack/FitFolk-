import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

function Toggle({ on, onClick, label }) {
  return (
    <button className={`toggle${on ? ' on' : ''}`} onClick={onClick} aria-pressed={on} aria-label={label}>
      <i />
    </button>
  );
}

export default function Settings() {
  const nav = useNavigate();
  const { settings, saveSettings, exportData, resetProgress, profile } = useApp();

  const patch = (partial) => saveSettings({ ...settings, ...partial });

  const download = async () => {
    const data = await exportData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'fitfolk-data.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const reset = async () => {
    const ok = window.confirm('Reset all local FitFolk data? This cannot be undone.');
    if (!ok) return;
    await resetProgress();
    nav('/', { replace: true });
  };

  return (
    <div className="page">
      <p className="eyebrow">Preferences</p>
      <h1>Settings</h1>
      {profile && <p>Signed in locally as {profile.name}.</p>}

      <div className="card">
        <div className="list-row">
          <div style={{ flex: 1 }}>
            <strong>Dark mode</strong>
            <div style={{ color: 'var(--muted)', fontSize: 13 }}>Default look for training at any hour</div>
          </div>
          <Toggle on={settings.darkMode} label="Dark mode" onClick={() => patch({ darkMode: !settings.darkMode })} />
        </div>
        <div className="list-row">
          <div style={{ flex: 1 }}>
            <strong>Units</strong>
            <div style={{ color: 'var(--muted)', fontSize: 13 }}>Weight and body measurements</div>
          </div>
          <button className="btn btn-ghost" style={{ width: 'auto' }} onClick={() => patch({ units: settings.units === 'kg' ? 'lbs' : 'kg' })}>
            {settings.units === 'lbs' ? 'lbs / in' : 'kg / cm'}
          </button>
        </div>
      </div>

      <div className="card">
        <h3>Notifications</h3>
        <p>Reminders stay on-device. Enable system notifications after install if you want banners.</p>
        {[
          ['workoutReminders', 'Workout reminders'],
          ['streakAlerts', 'Streak alerts'],
          ['weeklySummary', 'Weekly summary'],
        ].map(([key, label]) => (
          <div className="list-row" key={key}>
            <div style={{ flex: 1 }}><strong>{label}</strong></div>
            <Toggle
              on={!!settings.notifications?.[key]}
              label={label}
              onClick={() =>
                patch({
                  notifications: { ...settings.notifications, [key]: !settings.notifications?.[key] },
                })
              }
            />
          </div>
        ))}
      </div>

      <div className="card">
        <h3>Data</h3>
        <div className="btn-row">
          <button className="btn btn-blue" onClick={download}>Export user data</button>
          <button className="btn btn-danger" onClick={reset}>Reset progress</button>
        </div>
      </div>
    </div>
  );
}
