import { useMusic } from '../context/MusicContext';

function fmt(t) {
  if (!t || Number.isNaN(t)) return '0:00';
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export default function Music() {
  const {
    tracks, current, playing, shuffle, repeat, volume, progress, duration,
    play, pause, next, prev, seek, changeVolume, setShuffle, setRepeat, addFiles, removeTrack, playTrack,
  } = useMusic();

  return (
    <div className="page">
      <p className="eyebrow">Soundtrack</p>
      <h1>Music</h1>
      <p>Built-in tones keep you moving. Upload your own MP3s for a personal playlist. Audio keeps playing during workouts.</p>

      <div className="card">
        <h3>{current?.title || 'Nothing queued'}</h3>
        <p style={{ marginTop: 0 }}>{current?.artist}</p>
        <input
          type="range"
          min="0"
          max={duration || 0}
          value={progress || 0}
          onChange={(e) => seek(Number(e.target.value))}
          style={{ width: '100%' }}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--muted)', fontSize: 12 }}>
          <span>{fmt(progress)}</span>
          <span>{fmt(duration)}</span>
        </div>
        <div className="btn-row" style={{ marginTop: 10 }}>
          <button className="btn btn-ghost" onClick={prev}>Prev</button>
          <button className="btn btn-primary" onClick={playing ? pause : play}>{playing ? 'Pause' : 'Play'}</button>
          <button className="btn btn-ghost" onClick={() => next()}>Next</button>
        </div>
        <div className="btn-row" style={{ marginTop: 10 }}>
          <button className={`btn ${shuffle ? 'btn-primary' : 'btn-ghost'}`} onClick={() => setShuffle((s) => !s)}>Shuffle</button>
          <button className={`btn ${repeat !== 'off' ? 'btn-blue' : 'btn-ghost'}`} onClick={() => setRepeat((r) => (r === 'off' ? 'all' : r === 'all' ? 'one' : 'off'))}>
            Repeat: {repeat}
          </button>
        </div>
        <div className="field" style={{ marginTop: 12 }}>
          <label>Volume</label>
          <input type="range" min="0" max="1" step="0.01" value={volume} onChange={(e) => changeVolume(e.target.value)} />
        </div>
      </div>

      <div className="card">
        <h3>Upload local files</h3>
        <input type="file" accept="audio/mpeg,audio/mp3,audio/*" multiple onChange={(e) => addFiles(e.target.files)} />
      </div>

      <div className="card">
        <h3>Playlist</h3>
        {tracks.map((t) => (
          <div className="list-row" key={t.id}>
            <div style={{ flex: 1 }}>
              <strong>{t.title}</strong>
              <div style={{ color: 'var(--muted)', fontSize: 13 }}>{t.builtin ? 'FitFolk Radio' : t.artist}</div>
            </div>
            <button className="btn btn-ghost" style={{ width: 'auto', padding: '8px 10px' }} onClick={() => playTrack(t.id)}>Play</button>
            {!t.builtin && (
              <button className="btn btn-danger" style={{ width: 'auto', padding: '8px 10px' }} onClick={() => removeTrack(t.id)}>Remove</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
