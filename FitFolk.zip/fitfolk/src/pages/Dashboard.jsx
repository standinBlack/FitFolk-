import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import MiniPlayer from '../components/MiniPlayer';
import ExerciseAnimation from '../components/ExerciseAnimation';
import { todayISO, weekDates } from '../utils/dates';

export default function Dashboard() {
  const nav = useNavigate();
  const { profile, todayWorkout, streak, completionPct, sessions, completedDates, settings } = useApp();
  const week = weekDates();
  const today = todayISO();

  const weeklyRate = useMemo(() => {
    const done = week.filter((d) => completedDates.includes(d)).length;
    return Math.round((done / 7) * 100);
  }, [week, completedDates]);

  return (
    <div className="page">
      <div className="topbar">
        <div>
          <p className="eyebrow">Dashboard</p>
          <h1 style={{ fontSize: 28 }}>Hey {profile?.name || 'athlete'}</h1>
        </div>
        <span className="badge">{settings.units === 'lbs' ? 'lbs' : 'kg'}</span>
      </div>

      <div className="desktop-grid">
        <div>
          <motion.div className="card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            <p className="eyebrow">Today</p>
            <h2>{todayWorkout ? todayWorkout.title : 'Rest and recharge'}</h2>
            <p style={{ marginTop: 0 }}>
              {todayWorkout
                ? `${todayWorkout.focus} · ${todayWorkout.duration} min · ${todayWorkout.exercises.length} moves`
                : 'Your plan will appear after onboarding.'}
            </p>
            <div className="progress-track" style={{ margin: '12px 0 16px' }}>
              <div className="progress-fill" style={{ width: `${completionPct}%` }} />
            </div>
            {todayWorkout?.exercises?.[0] && (
              <div style={{ margin: '12px 0' }}>
                <ExerciseAnimation exerciseId={todayWorkout.exercises[0].id} title={todayWorkout.exercises[0].name} />
              </div>
            )}
            <button className="btn btn-primary" disabled={!todayWorkout} onClick={() => nav(`/app/workout/${todayWorkout.id}`)}>
              Quick Start Workout
            </button>
          </motion.div>

          <div className="card">
            <h3>This week</h3>
            <div className="week-row">
              {week.map((d) => {
                const label = new Date(`${d}T12:00:00`).toLocaleDateString(undefined, { weekday: 'narrow' });
                const done = completedDates.includes(d);
                const miss = d < today && !done && new Date(`${d}T12:00:00`) < new Date();
                return (
                  <div key={d} className={`week-cell${done ? ' done' : ''}${miss ? ' miss' : ''}${d === today ? ' today' : ''}`}>
                    {label}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div>
          <div className="stat-grid">
            <div className="stat"><b>{streak}</b><span>Day streak</span></div>
            <div className="stat"><b>{completionPct}%</b><span>Goal progress</span></div>
            <div className="stat"><b>{weeklyRate}%</b><span>Weekly completion</span></div>
            <div className="stat"><b>{sessions.length}</b><span>Sessions logged</span></div>
          </div>
          <MiniPlayer />
        </div>
      </div>
    </div>
  );
}
