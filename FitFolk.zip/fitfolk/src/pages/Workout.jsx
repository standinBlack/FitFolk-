import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { getExercise } from '../data/exercises';
import MiniPlayer from '../components/MiniPlayer';
import ExerciseAnimation from '../components/ExerciseAnimation';

export default function Workout() {
  const { dayId } = useParams();
  const nav = useNavigate();
  const { plan, logSession, todayWorkout } = useApp();
  const day = useMemo(() => {
    const days = plan?.weeks?.flatMap((w) => w.days) || [];
    return days.find((d) => d.id === dayId) || todayWorkout;
  }, [plan, dayId, todayWorkout]);

  const [exIndex, setExIndex] = useState(0);
  const [setIndex, setSetIndex] = useState(0);
  const [phase, setPhase] = useState('ready');
  const [remaining, setRemaining] = useState(0);
  const [startedAt] = useState(Date.now());
  const [skipped, setSkipped] = useState(0);
  const timerRef = useRef(null);

  const exercise = day?.exercises?.[exIndex];
  const meta = exercise ? getExercise(exercise.id) : null;
  const totalSets = exercise?.sets || 1;
  const totalMoves = day?.exercises?.length || 1;
  const overall = ((exIndex + setIndex / totalSets) / totalMoves) * 100;

  useEffect(() => () => clearInterval(timerRef.current), []);

  const startTimer = (seconds, onDone) => {
    clearInterval(timerRef.current);
    setRemaining(seconds);
    timerRef.current = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(timerRef.current);
          onDone();
          return 0;
        }
        return r - 1;
      });
    }, 1000);
  };

  const finishSet = () => {
    if (setIndex + 1 < totalSets) {
      setPhase('rest');
      startTimer(exercise.rest || 30, () => {
        setSetIndex((s) => s + 1);
        setPhase(exercise.timed ? 'work' : 'ready');
        if (exercise.timed) startWork();
      });
    } else {
      nextExercise();
    }
  };

  const startWork = () => {
    if (!exercise) return;
    if (exercise.timed) {
      setPhase('work');
      startTimer(exercise.seconds || 20, finishSet);
    } else {
      setPhase('work');
    }
  };

  const nextExercise = () => {
    clearInterval(timerRef.current);
    if (exIndex + 1 < totalMoves) {
      setExIndex((i) => i + 1);
      setSetIndex(0);
      setPhase('ready');
    } else {
      complete(false);
    }
  };

  const complete = async (wasSkip) => {
    clearInterval(timerRef.current);
    await logSession({
      dayId: day.id,
      title: day.title,
      durationSec: Math.round((Date.now() - startedAt) / 1000),
      exercisesDone: exIndex + (wasSkip ? 0 : 1),
      skipped: false,
    });
    nav('/app');
  };

  if (!day || !exercise) {
    return (
      <div className="page">
        <h1>No workout found</h1>
        <button className="btn btn-primary" onClick={() => nav('/app')}>Back home</button>
      </div>
    );
  }

  return (
    <div className="page">
      <p className="eyebrow">{day.title} · Week {day.week}</p>
      <h1 style={{ fontSize: 28 }}>{exercise.name}</h1>
      <p>{meta?.description}</p>

      <ExerciseAnimation exerciseId={exercise.id} playing={phase !== 'paused'} title={exercise.name} />

      <div className="progress-track" style={{ margin: '14px 0' }}>
        <div className="progress-fill" style={{ width: `${Math.min(100, overall)}%` }} />
      </div>

      <div className="stat-grid">
        <div className="stat"><b>{setIndex + 1}/{totalSets}</b><span>Current set</span></div>
        <div className="stat"><b>{totalSets - setIndex - 1}</b><span>Sets remaining</span></div>
        <div className="stat"><b>{exercise.timed ? `${exercise.seconds}s` : `${exercise.reps}`}</b><span>{exercise.timed ? 'Hold / work' : 'Reps'}</span></div>
        <div className="stat"><b>{phase === 'rest' || phase === 'work' ? `${remaining}s` : '—'}</b><span>Timer</span></div>
      </div>

      <div className="card" style={{ marginTop: 12 }}>
        <p style={{ margin: 0, textTransform: 'capitalize' }}>Status: {phase}</p>
      </div>

      <div className="btn-row" style={{ marginTop: 14 }}>
        {phase === 'ready' && <button className="btn btn-primary" onClick={startWork}>Start</button>}
        {phase === 'work' && !exercise.timed && <button className="btn btn-primary" onClick={finishSet}>Finish set</button>}
        {(phase === 'work' || phase === 'rest') && (
          <button className="btn btn-ghost" onClick={() => { clearInterval(timerRef.current); setPhase('paused'); }}>Pause</button>
        )}
        {phase === 'paused' && (
          <button className="btn btn-blue" onClick={() => {
            if (remaining > 0) startTimer(remaining, phase === 'rest' || exercise.timed ? finishSet : () => {});
            else startWork();
            setPhase(exercise.timed || remaining > 0 ? (remaining && remaining < (exercise.rest || 40) ? 'rest' : 'work') : 'work');
          }}>Resume</button>
        )}
        <button className="btn btn-ghost" onClick={() => { setSkipped((n) => n + 1); nextExercise(); }}>Skip</button>
      </div>
      <button className="btn btn-danger" style={{ width: '100%', marginTop: 10 }} onClick={() => complete(true)}>Finish workout</button>
      <MiniPlayer />
    </div>
  );
}
