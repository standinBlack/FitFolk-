import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '../context/AppContext';

const GOALS = ['Build Six-Pack Abs', 'Build Chest', 'Gain Muscle', 'Lose Weight', 'Full Body Fitness', 'Improve Stamina', 'Stay Healthy'];
const TIMES = ['30 Days', '60 Days', '90 Days', 'Flexible'];
const LEVELS = ['Beginner', 'Intermediate', 'Advanced'];
const DURATIONS = ['10 Minutes', '15 Minutes', '20 Minutes', '30 Minutes', '45 Minutes', '60+ Minutes'];
const GEAR = ['None', 'Dumbbells', 'Resistance Bands', 'Pull-Up Bar', 'Bench', 'Full Gym Access'];
const PLACES = ['Home', 'Gym', 'Both'];
const INJURIES = ['Back Issues', 'Knee Issues', 'Shoulder Issues', 'Other'];
const MOTIVES = ['Better Appearance', 'Strength', 'Health', 'Sports Performance', 'Confidence', 'Other'];
const STYLES = ['Fast and Intense', 'Moderate', 'Slow and Steady'];

const STEPS = [
  'Personal Information',
  'Fitness Goal',
  'Goal Timeline',
  'Fitness Level',
  'Daily Workout Time',
  'Available Equipment',
  'Training Location',
  'Injuries or Limitations',
  'Motivation',
  'Preferred Workout Style',
];

function Chip({ label, active, onClick, blue }) {
  return (
    <button type="button" className={`chip${blue ? ' blue' : ''}${active ? ' active' : ''}`} onClick={onClick}>
      {label}
    </button>
  );
}

export default function Onboarding() {
  const nav = useNavigate();
  const { draft, setDraft, settings } = useApp();
  const [step, setStep] = useState(0);
  const units = settings.units || 'kg';

  const data = useMemo(
    () => ({
      name: '',
      age: '',
      gender: '',
      height: '',
      weight: '',
      goal: '',
      timeline: '',
      level: '',
      dailyTime: '',
      equipment: [],
      location: '',
      injuries: [],
      motivation: '',
      style: '',
      ...draft,
    }),
    [draft],
  );

  const update = (patch) => setDraft({ ...data, ...patch });

  const toggleIn = (key, value) => {
    const arr = data[key] || [];
    update({ [key]: arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value] });
  };

  const canNext = () => {
    switch (step) {
      case 0:
        return data.name && data.age && data.gender && data.height && data.weight;
      case 1:
        return !!data.goal;
      case 2:
        return !!data.timeline;
      case 3:
        return !!data.level;
      case 4:
        return !!data.dailyTime;
      case 5:
        return (data.equipment || []).length > 0;
      case 6:
        return !!data.location;
      case 7:
        return true;
      case 8:
        return !!data.motivation;
      case 9:
        return !!data.style;
      default:
        return false;
    }
  };

  const next = () => {
    if (step === STEPS.length - 1) nav('/assessment');
    else setStep((s) => s + 1);
  };

  return (
    <div className="page">
      <p className="eyebrow">Questionnaire {step + 1}/{STEPS.length}</p>
      <h1 style={{ fontSize: 28 }}>{STEPS[step]}</h1>
      <div className="step-dots" aria-hidden>
        {STEPS.map((_, i) => (
          <span key={i} className={i <= step ? 'on' : ''} />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={step} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.2 }}>
          {step === 0 && (
            <>
              <div className="field">
                <label htmlFor="name">Name or nickname</label>
                <input id="name" value={data.name} onChange={(e) => update({ name: e.target.value })} placeholder="Alex" />
              </div>
              <div className="field">
                <label htmlFor="age">Age</label>
                <input id="age" type="number" min="13" max="90" value={data.age} onChange={(e) => update({ age: e.target.value })} />
              </div>
              <p style={{ marginTop: 0, marginBottom: 8, fontSize: 13 }}>Gender</p>
              <div className="chip-grid">
                {['Female', 'Male', 'Non-binary', 'Prefer not to say'].map((g) => (
                  <Chip key={g} label={g} active={data.gender === g} onClick={() => update({ gender: g })} />
                ))}
              </div>
              <div className="field" style={{ marginTop: 14 }}>
                <label htmlFor="height">Height ({units === 'lbs' ? 'in' : 'cm'})</label>
                <input id="height" type="number" value={data.height} onChange={(e) => update({ height: e.target.value })} />
              </div>
              <div className="field">
                <label htmlFor="weight">Weight ({units})</label>
                <input id="weight" type="number" value={data.weight} onChange={(e) => update({ weight: e.target.value })} />
              </div>
            </>
          )}

          {step === 1 && (
            <div className="chip-grid">
              {GOALS.map((g) => (
                <Chip key={g} label={g} active={data.goal === g} onClick={() => update({ goal: g })} />
              ))}
            </div>
          )}
          {step === 2 && (
            <div className="chip-grid">
              {TIMES.map((g) => (
                <Chip key={g} label={g} active={data.timeline === g} onClick={() => update({ timeline: g })} blue />
              ))}
            </div>
          )}
          {step === 3 && (
            <div className="chip-grid">
              {LEVELS.map((g) => (
                <Chip key={g} label={g} active={data.level === g} onClick={() => update({ level: g })} />
              ))}
            </div>
          )}
          {step === 4 && (
            <div className="chip-grid">
              {DURATIONS.map((g) => (
                <Chip key={g} label={g} active={data.dailyTime === g} onClick={() => update({ dailyTime: g })} blue />
              ))}
            </div>
          )}
          {step === 5 && (
            <>
              <p>Select everything you can use. Choose None if you train with bodyweight only.</p>
              <div className="chip-grid">
                {GEAR.map((g) => (
                  <Chip key={g} label={g} active={(data.equipment || []).includes(g)} onClick={() => toggleIn('equipment', g)} />
                ))}
              </div>
            </>
          )}
          {step === 6 && (
            <div className="chip-grid">
              {PLACES.map((g) => (
                <Chip key={g} label={g} active={data.location === g} onClick={() => update({ location: g })} />
              ))}
            </div>
          )}
          {step === 7 && (
            <>
              <p>Optional. We will avoid movements that commonly aggravate these areas.</p>
              <div className="chip-grid">
                {INJURIES.map((g) => (
                  <Chip key={g} label={g} active={(data.injuries || []).includes(g)} onClick={() => toggleIn('injuries', g)} blue />
                ))}
              </div>
            </>
          )}
          {step === 8 && (
            <div className="chip-grid">
              {MOTIVES.map((g) => (
                <Chip key={g} label={g} active={data.motivation === g} onClick={() => update({ motivation: g })} />
              ))}
            </div>
          )}
          {step === 9 && (
            <div className="chip-grid">
              {STYLES.map((g) => (
                <Chip key={g} label={g} active={data.style === g} onClick={() => update({ style: g })} blue />
              ))}
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      <div className="btn-row" style={{ marginTop: 22 }}>
        <button className="btn btn-ghost" onClick={() => (step === 0 ? nav('/welcome') : setStep((s) => s - 1))}>
          Back
        </button>
        <button className="btn btn-primary" disabled={!canNext()} onClick={next}>
          {step === STEPS.length - 1 ? 'Continue' : 'Next'}
        </button>
      </div>
    </div>
  );
}
