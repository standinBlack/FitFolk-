import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Logo from '../components/Logo';

const benefits = [
  { title: 'Built around you', text: 'Plans adapt to your goal, time, gear, and starting point.' },
  { title: 'No account needed', text: 'Everything stays on this device. Train offline anytime.' },
  { title: 'Progress you can see', text: 'Streaks, measurements, and photos keep momentum visible.' },
];

export default function Welcome() {
  const nav = useNavigate();
  return (
    <div className="page" style={{ paddingTop: 48 }}>
      <Logo />
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <p className="eyebrow" style={{ marginTop: 28 }}>Free coaching</p>
        <h1>Train with a plan that actually fits your life.</h1>
        <p>FitFolk builds a personal schedule from a short questionnaire and a simple fitness check. No gym required unless you have one.</p>
      </motion.div>
      <div style={{ marginTop: 20 }}>
        {benefits.map((b) => (
          <div className="card" key={b.title}>
            <h3 style={{ marginBottom: 4 }}>{b.title}</h3>
            <p style={{ margin: 0 }}>{b.text}</p>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 24 }}>
        <button className="btn btn-primary" onClick={() => nav('/onboarding')}>Get Started</button>
      </div>
    </div>
  );
}
