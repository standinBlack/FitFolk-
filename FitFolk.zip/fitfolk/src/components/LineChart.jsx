export default function LineChart({ points = [], color = '#2ee59d' }) {
  const vals = points.filter((p) => p != null && !Number.isNaN(p));
  if (vals.length < 2) {
    return <p style={{ margin: 0 }}>Add at least two measurements to see a trend.</p>;
  }
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const span = max - min || 1;
  const w = 320;
  const h = 140;
  const pad = 12;
  const coords = vals.map((v, i) => {
    const x = pad + (i * (w - pad * 2)) / (vals.length - 1);
    const y = h - pad - ((v - min) / span) * (h - pad * 2);
    return `${x},${y}`;
  });
  return (
    <svg className="chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Progress chart">
      <polyline fill="none" stroke={color} strokeWidth="3" strokeLinejoin="round" strokeLinecap="round" points={coords.join(' ')} />
      {coords.map((c, i) => {
        const [x, y] = c.split(',');
        return <circle key={i} cx={x} cy={y} r="4" fill={color} />;
      })}
    </svg>
  );
}
