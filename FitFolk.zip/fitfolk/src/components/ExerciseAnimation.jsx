import './exerciseAnimations.css';

const TYPE = {
  pushup: 'pushup',
  'knee-pushup': 'knee-pushup',
  'incline-pushup': 'incline-pushup',
  'wide-pushup': 'wide-pushup',
  'diamond-pushup': 'diamond-pushup',
  'db-press': 'press',
  'db-fly': 'fly',
  'band-chest-press': 'stand-press',
  plank: 'plank',
  'side-plank': 'side-plank',
  crunch: 'crunch',
  'leg-raise': 'raise',
  bicycle: 'bicycle',
  'mountain-climber': 'climber',
  'dead-bug': 'dead-bug',
  'bodyweight-squat': 'squat',
  'split-squat': 'lunge',
  'reverse-lunge': 'lunge',
  'glute-bridge': 'bridge',
  'calf-raise': 'calf',
  'goblet-squat': 'squat',
  'band-squat': 'squat',
  superman: 'superman',
  'bird-dog': 'bird',
  'inverted-row': 'row-hang',
  pullup: 'pullup',
  'band-row': 'row',
  'db-row': 'row',
  'lat-pulldown': 'pulldown',
  'pike-pushup': 'pike',
  'pike-hold': 'pike-hold',
  'db-curl': 'curl',
  'triceps-dip': 'dip',
  'band-curl': 'curl',
  'shoulder-tap': 'tap',
  burpee: 'burpee',
  'jumping-jack': 'jack',
  'high-knees': 'run',
  'jog-place': 'run',
  'jump-squat': 'jump-squat',
  'wall-sit': 'wall-sit',
  'hollow-hold': 'hollow',
  'russian-twist': 'twist',
  'good-morning': 'hinge',
  'farmer-carry': 'carry',
};

function Head({ cx, cy, r = 10 }) {
  return <circle className="head" cx={cx} cy={cy} r={r} />;
}

function PushFamily({ variant }) {
  const knee = variant === 'knee-pushup';
  const incline = variant === 'incline-pushup';
  const wide = variant === 'wide-pushup';
  const diamond = variant === 'diamond-pushup';
  const y = incline ? 78 : 92;
  const handY = incline ? 70 : 108;
  const handGap = diamond ? 6 : wide ? 64 : 42;
  return (
    <g className="anim-pushup">
      {incline && <rect className="bench" x="28" y="62" width="70" height="14" rx="4" />}
      <line className="floor" x1="20" y1="148" x2="180" y2="148" />
      <g className="body-group">
        <Head cx="156" cy={y - 10} />
        <path className="fig" d={`M148 ${y} L70 ${y + 4}`} />
        <path className={`fig arm-l`} d={`M78 ${y + 2} L${100 - handGap} ${handY}`} />
        <path className={`fig arm-r`} d={`M78 ${y + 2} L${100 + (diamond ? 2 : 8)} ${handY}`} />
        {knee ? (
          <>
            <path className="fig" d={`M70 ${y + 4} L92 132`} />
            <path className="fig" d={`M70 ${y + 4} L58 132`} />
          </>
        ) : (
          <>
            <path className="fig" d={`M70 ${y + 4} L48 140`} />
            <path className="fig" d={`M70 ${y + 4} L36 140`} />
          </>
        )}
      </g>
    </g>
  );
}

function PressFly({ fly }) {
  return (
    <g className={fly ? 'anim-fly' : 'anim-press'}>
      <rect className="bench" x="46" y="108" width="108" height="16" rx="4" />
      <g className="body-group">
        <Head cx="40" cy="96" />
        <path className="fig" d="M50 100 H150" />
        <g className={fly ? undefined : 'arms'}>
          <path className="fig arm-l" d="M92 100 L64 72" />
          <path className="fig arm-r" d="M108 100 L136 72" />
          <circle className="weight" cx="62" cy="68" r="7" />
          <circle className="weight" cx="138" cy="68" r="7" />
        </g>
      </g>
    </g>
  );
}

function StandPress() {
  return (
    <g className="anim-press">
      <line className="floor" x1="30" y1="160" x2="170" y2="160" />
      <path className="band" d="M70 160 Q100 120 70 78" />
      <path className="band" d="M130 160 Q100 120 130 78" />
      <g className="body-group">
        <Head cx="100" cy="42" />
        <path className="fig" d="M100 52 V108" />
        <g className="arms">
          <path className="fig" d="M100 64 L70 78" />
          <path className="fig" d="M100 64 L130 78" />
        </g>
        <path className="fig" d="M100 108 L78 158" />
        <path className="fig" d="M100 108 L122 158" />
      </g>
    </g>
  );
}

function PlankHold({ side }) {
  return (
    <g className="anim-hold">
      <line className="floor" x1="20" y1="150" x2="180" y2="150" />
      <g className="body-group">
        {side ? (
          <>
            <Head cx="156" cy="78" />
            <path className="fig" d="M146 86 L64 96" />
            <path className="fig" d="M64 96 L52 146" />
            <path className="fig" d="M146 86 L138 146" />
          </>
        ) : (
          <>
            <Head cx="158" cy="84" />
            <path className="fig" d="M148 90 L62 96" />
            <path className="fig" d="M72 96 L58 146" />
            <path className="fig" d="M62 96 L48 146" />
            <path className="fig" d="M148 90 L168 146" />
          </>
        )}
      </g>
    </g>
  );
}

function Crunch() {
  return (
    <g className="anim-crunch">
      <line className="floor" x1="24" y1="150" x2="176" y2="150" />
      <path className="fig" d="M86 118 L160 118" />
      <g className="torso">
        <Head cx="58" cy="86" />
        <path className="fig" d="M66 96 L118 118" />
        <path className="fig" d="M78 102 L96 86" />
      </g>
    </g>
  );
}

function LegRaise() {
  return (
    <g className="anim-raise">
      <line className="floor" x1="24" y1="150" x2="176" y2="150" />
      <Head cx="48" cy="108" />
      <path className="fig" d="M58 112 H96" />
      <g className="legs">
        <path className="fig" d="M96 112 L150 124" />
        <path className="fig" d="M96 112 L146 136" />
      </g>
    </g>
  );
}

function BicycleAnim() {
  return (
    <g className="anim-climber">
      <line className="floor" x1="24" y1="154" x2="176" y2="154" />
      <Head cx="64" cy="78" />
      <path className="fig" d="M72 88 L110 108" />
      <path className="fig arm-l" d="M84 94 L128 78" />
      <path className="fig leg-l" d="M110 108 L86 142" />
      <path className="fig leg-r" d="M110 108 L150 86" />
    </g>
  );
}

function Climber() {
  return (
    <g className="anim-climber">
      <line className="floor" x1="20" y1="150" x2="180" y2="150" />
      <Head cx="156" cy="78" />
      <path className="fig" d="M146 86 L70 90" />
      <path className="fig" d="M78 88 L52 148" />
      <path className="fig" d="M78 88 L64 148" />
      <path className="fig leg-l" d="M70 90 L96 148" />
      <path className="fig leg-r" d="M70 90 L118 78" />
    </g>
  );
}

function DeadBug() {
  return (
    <g className="anim-climber">
      <line className="floor" x1="24" y1="150" x2="176" y2="150" />
      <Head cx="46" cy="104" />
      <path className="fig" d="M56 108 H112" />
      <path className="fig arm-l" d="M70 108 L48 70" />
      <path className="fig arm-r" d="M70 108 L110 78" />
      <path className="fig leg-l" d="M112 108 L150 78" />
      <path className="fig leg-r" d="M112 108 L142 142" />
    </g>
  );
}

function Squat({ goblet }) {
  return (
    <g className="anim-squat">
      <line className="floor" x1="30" y1="160" x2="170" y2="160" />
      <g className="torso">
        <Head cx="100" cy="36" />
        <path className="fig" d="M100 46 V96" />
        <path className="fig" d="M100 58 L78 78" />
        <path className="fig" d="M100 58 L122 78" />
        {goblet && <circle className="weight" cx="100" cy="70" r="8" />}
      </g>
      <path className="fig" d="M100 96 L78 158" />
      <path className="fig" d="M100 96 L122 158" />
    </g>
  );
}

function Lunge() {
  return (
    <g className="anim-lunge">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <g className="torso">
        <Head cx="108" cy="36" />
        <path className="fig" d="M108 46 V100" />
        <path className="fig" d="M108 60 L88 80" />
        <path className="fig" d="M108 60 L128 80" />
      </g>
      <path className="fig" d="M108 100 L84 158" />
      <path className="fig" d="M108 100 L150 158" />
    </g>
  );
}

function Bridge() {
  return (
    <g className="anim-bridge">
      <line className="floor" x1="24" y1="150" x2="176" y2="150" />
      <g className="body-group">
        <Head cx="40" cy="118" />
        <path className="fig" d="M50 118 L128 118" />
        <path className="fig" d="M128 118 L148 148" />
        <path className="fig" d="M128 118 L138 148" />
      </g>
    </g>
  );
}

function Calf() {
  return (
    <g className="anim-calf">
      <line className="floor" x1="30" y1="160" x2="170" y2="160" />
      <g className="body-group">
        <Head cx="100" cy="34" />
        <path className="fig" d="M100 44 V108" />
        <path className="fig" d="M100 108 L86 150" />
        <path className="fig" d="M100 108 L114 150" />
        <path className="fig" d="M100 58 L80 86" />
        <path className="fig" d="M100 58 L120 86" />
      </g>
    </g>
  );
}

function Superman() {
  return (
    <g className="anim-super">
      <line className="floor" x1="24" y1="132" x2="176" y2="132" />
      <g className="limbs">
        <Head cx="44" cy="108" />
        <path className="fig" d="M54 112 H140" />
        <path className="fig" d="M54 112 L28 96" />
        <path className="fig" d="M140 112 L168 96" />
      </g>
    </g>
  );
}

function BirdDog() {
  return (
    <g className="anim-bird">
      <line className="floor" x1="24" y1="150" x2="176" y2="150" />
      <Head cx="52" cy="86" />
      <path className="fig" d="M62 94 H118" />
      <path className="fig" d="M72 94 L62 146" />
      <path className="fig arm" d="M62 94 L28 78" />
      <path className="fig leg" d="M118 108 L156 78" />
      <path className="fig" d="M118 94 L118 108" />
    </g>
  );
}

function Row({ hang }) {
  return hang ? (
    <g className="anim-row">
      <line className="bar" x1="36" y1="48" x2="164" y2="48" />
      <g>
        <Head cx="156" cy="96" />
        <path className="fig" d="M146 100 L70 104" />
        <path className="fig arm" d="M86 102 L86 48" />
        <path className="fig" d="M70 104 L52 140" />
      </g>
    </g>
  ) : (
    <g className="anim-row">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <Head cx="58" cy="58" />
      <path className="fig" d="M66 68 L120 112" />
      <path className="fig" d="M120 112 L108 158" />
      <path className="fig" d="M120 112 L140 158" />
      <path className="fig arm" d="M96 90 L132 70" />
      <circle className="weight" cx="136" cy="66" r="7" />
    </g>
  );
}

function PullUp() {
  return (
    <g className="anim-pull">
      <line className="bar" x1="40" y1="36" x2="160" y2="36" />
      <g className="body-group">
        <path className="fig" d="M70 36 L78 70" />
        <path className="fig" d="M130 36 L122 70" />
        <Head cx="100" cy="86" />
        <path className="fig" d="M100 96 V132" />
        <path className="fig" d="M100 132 L86 156" />
        <path className="fig" d="M100 132 L114 156" />
      </g>
    </g>
  );
}

function Pulldown() {
  return (
    <g className="anim-press">
      <line className="bar" x1="50" y1="28" x2="150" y2="28" />
      <path className="fig" d="M70 28 L78 70" />
      <path className="fig" d="M130 28 L122 70" />
      <g className="arms">
        <Head cx="100" cy="90" />
        <path className="fig" d="M100 100 V138" />
        <path className="fig" d="M100 138 L82 158" />
        <path className="fig" d="M100 138 L118 158" />
      </g>
    </g>
  );
}

function Pike({ hold }) {
  return (
    <g className={hold ? 'anim-hold' : 'anim-pushup'}>
      <line className="floor" x1="24" y1="150" x2="176" y2="150" />
      <g className="body-group">
        <Head cx="58" cy="96" />
        <path className="fig" d="M66 104 L100 58" />
        <path className="fig" d="M100 58 L150 148" />
        <path className="fig arm-l" d="M66 104 L48 148" />
      </g>
    </g>
  );
}

function Curl() {
  return (
    <g className="anim-curl">
      <line className="floor" x1="30" y1="160" x2="170" y2="160" />
      <Head cx="100" cy="36" />
      <path className="fig" d="M100 46 V108" />
      <path className="fig" d="M100 108 L82 158" />
      <path className="fig" d="M100 108 L118 158" />
      <path className="fig" d="M100 62 L118 108" />
      <path className="fig fore" d="M118 108 L138 128" />
      <circle className="weight" cx="142" cy="132" r="7" />
    </g>
  );
}

function Dip() {
  return (
    <g className="anim-dip">
      <rect className="bench" x="36" y="78" width="128" height="12" rx="3" />
      <g className="body-group">
        <Head cx="100" cy="52" />
        <path className="fig" d="M100 62 V110" />
        <path className="fig" d="M100 72 L64 84" />
        <path className="fig" d="M100 72 L136 84" />
        <path className="fig" d="M100 110 L88 146" />
        <path className="fig" d="M100 110 L112 146" />
      </g>
    </g>
  );
}

function Tap() {
  return (
    <g className="anim-tap">
      <line className="floor" x1="20" y1="150" x2="180" y2="150" />
      <Head cx="158" cy="78" />
      <path className="fig" d="M148 86 L70 92" />
      <path className="fig" d="M70 92 L48 148" />
      <path className="fig" d="M148 86 L166 148" />
      <path className="fig arm-l" d="M86 90 L120 70" />
    </g>
  );
}

function Jack() {
  return (
    <g className="anim-jack">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <Head cx="100" cy="36" />
      <path className="fig" d="M100 46 V110" />
      <path className="fig arm-l" d="M100 60 L78 96" />
      <path className="fig arm-r" d="M100 60 L122 96" />
      <path className="fig leg-l" d="M100 110 L84 158" />
      <path className="fig leg-r" d="M100 110 L116 158" />
    </g>
  );
}

function RunAnim() {
  return (
    <g className="anim-run">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <Head cx="108" cy="36" />
      <path className="fig" d="M108 46 V108" />
      <path className="fig" d="M108 60 L90 82" />
      <path className="fig" d="M108 60 L130 70" />
      <path className="fig leg-l" d="M108 108 L90 154" />
      <path className="fig leg-r" d="M108 108 L132 128" />
    </g>
  );
}

function JumpSquat() {
  return (
    <g className="anim-jump">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <g className="body-group">
        <Head cx="100" cy="34" />
        <path className="fig" d="M100 44 V96" />
        <path className="fig" d="M100 96 L80 140" />
        <path className="fig" d="M100 96 L120 140" />
        <path className="fig" d="M100 58 L78 78" />
        <path className="fig" d="M100 58 L122 78" />
      </g>
    </g>
  );
}

function WallSit() {
  return (
    <g className="anim-hold">
      <line className="fig" x1="48" y1="24" x2="48" y2="160" />
      <line className="floor" x1="48" y1="160" x2="176" y2="160" />
      <g className="body-group">
        <Head cx="78" cy="52" />
        <path className="fig" d="M78 62 V104" />
        <path className="fig" d="M78 104 H118" />
        <path className="fig" d="M118 104 V158" />
        <path className="fig" d="M78 74 L108 90" />
      </g>
    </g>
  );
}

function Hollow() {
  return (
    <g className="anim-hollow">
      <line className="floor" x1="24" y1="132" x2="176" y2="132" />
      <g className="body-group">
        <Head cx="42" cy="96" />
        <path className="fig" d="M52 102 L150 102" />
        <path className="fig" d="M52 102 L24 86" />
        <path className="fig" d="M150 102 L176 86" />
      </g>
    </g>
  );
}

function Twist() {
  return (
    <g className="anim-twist">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <g className="torso">
        <Head cx="100" cy="58" />
        <path className="fig" d="M100 68 V110" />
        <path className="fig" d="M100 80 L64 96" />
        <path className="fig" d="M100 80 L136 96" />
        <circle className="weight" cx="136" cy="96" r="6" />
      </g>
      <path className="fig" d="M100 110 L80 150" />
      <path className="fig" d="M100 110 L120 150" />
    </g>
  );
}

function Hinge() {
  return (
    <g className="anim-hinge">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <g className="torso">
        <Head cx="100" cy="36" />
        <path className="fig" d="M100 46 V108" />
        <path className="fig" d="M100 62 L80 86" />
        <path className="fig" d="M100 62 L120 86" />
      </g>
      <path className="fig" d="M100 108 L84 158" />
      <path className="fig" d="M100 108 L116 158" />
    </g>
  );
}

function Carry() {
  return (
    <g className="anim-walk">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <Head cx="100" cy="34" />
      <path className="fig" d="M100 44 V108" />
      <path className="fig" d="M100 62 L74 108" />
      <path className="fig" d="M100 62 L126 108" />
      <circle className="weight" cx="74" cy="114" r="8" />
      <circle className="weight" cx="126" cy="114" r="8" />
      <path className="fig leg-l" d="M100 108 L84 158" />
      <path className="fig leg-r" d="M100 108 L118 158" />
    </g>
  );
}

function Burpee() {
  return (
    <g className="anim-burpee">
      <line className="floor" x1="24" y1="160" x2="176" y2="160" />
      <g className="body-group">
        <Head cx="100" cy="36" />
        <path className="fig" d="M100 46 V108" />
        <path className="fig" d="M100 60 L78 86" />
        <path className="fig" d="M100 60 L122 86" />
        <path className="fig" d="M100 108 L82 156" />
        <path className="fig" d="M100 108 L118 156" />
      </g>
    </g>
  );
}

const SCENES = {
  pushup: () => <PushFamily variant="pushup" />,
  'knee-pushup': () => <PushFamily variant="knee-pushup" />,
  'incline-pushup': () => <PushFamily variant="incline-pushup" />,
  'wide-pushup': () => <PushFamily variant="wide-pushup" />,
  'diamond-pushup': () => <PushFamily variant="diamond-pushup" />,
  press: () => <PressFly />,
  fly: () => <PressFly fly />,
  'stand-press': StandPress,
  plank: () => <PlankHold />,
  'side-plank': () => <PlankHold side />,
  crunch: Crunch,
  raise: LegRaise,
  bicycle: BicycleAnim,
  climber: Climber,
  'dead-bug': DeadBug,
  squat: () => <Squat />,
  lunge: Lunge,
  bridge: Bridge,
  calf: Calf,
  superman: Superman,
  bird: BirdDog,
  row: () => <Row />,
  'row-hang': () => <Row hang />,
  pullup: PullUp,
  pulldown: Pulldown,
  pike: () => <Pike />,
  'pike-hold': () => <Pike hold />,
  curl: Curl,
  dip: Dip,
  tap: Tap,
  jack: Jack,
  run: RunAnim,
  'jump-squat': JumpSquat,
  'wall-sit': WallSit,
  hollow: Hollow,
  twist: Twist,
  hinge: Hinge,
  carry: Carry,
  burpee: Burpee,
};

export default function ExerciseAnimation({ exerciseId, playing = true, compact = false, title }) {
  const type = TYPE[exerciseId] || 'plank';
  const Scene = SCENES[type] || SCENES.plank;
  return (
    <div className={`ex-stage${compact ? ' compact' : ''}${playing ? '' : ' paused'}`} aria-hidden={!title} role="img" aria-label={title || 'Exercise animation'}>
      <svg viewBox="0 0 200 170">
        <Scene />
      </svg>
    </div>
  );
}
