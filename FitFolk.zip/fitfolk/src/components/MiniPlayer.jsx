import { useMusic } from '../context/MusicContext';

export default function MiniPlayer() {
  const { current, playing, play, pause, next } = useMusic();
  if (!current) return null;
  return (
    <div className="mini-player" style={{ marginTop: 12 }}>
      <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--green-dim)', display: 'grid', placeItems: 'center', color: 'var(--green)', fontWeight: 800 }}>♪</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{current.title}</div>
        <div style={{ color: 'var(--muted)', fontSize: 12 }}>{current.artist}</div>
      </div>
      <button className="btn btn-ghost" style={{ padding: '8px 10px', width: 'auto' }} onClick={playing ? pause : play} aria-label={playing ? 'Pause' : 'Play'}>
        {playing ? 'Pause' : 'Play'}
      </button>
      <button className="btn btn-ghost" style={{ padding: '8px 10px', width: 'auto' }} onClick={() => next()} aria-label="Next">
        Next
      </button>
    </div>
  );
}
