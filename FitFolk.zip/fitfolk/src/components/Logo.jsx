import mark from '../assets/logo-mark.jpg';
import lockup from '../assets/logo-full.jpg';

export default function Logo({ size = 36, variant = 'compact' }) {
  if (variant === 'full') {
    return (
      <img
        src={lockup}
        alt="FitFolk — Fitness built around you."
        className="brand-lockup"
        style={{ width: size, height: 'auto' }}
      />
    );
  }

  if (variant === 'mark') {
    return (
      <img
        src={mark}
        alt="FitFolk"
        className="brand-mark-img"
        width={size}
        height={size}
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <div className="brand">
      <img
        src={mark}
        alt=""
        className="brand-mark-img"
        width={size}
        height={size}
        style={{ width: size, height: size }}
      />
      <span>FitFolk</span>
    </div>
  );
}
