export default function Logo({ size = 36 }) {
  return (
    <div className="brand">
      <div className="brand-mark" style={{ width: size, height: size, fontSize: size * 0.42 }}>
        Ff
      </div>
      <span>FitFolk</span>
    </div>
  );
}
