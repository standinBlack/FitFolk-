import { EXERCISES, EQUIPMENT, filterByEquipment, getExercise } from './exercises';

const GOAL_FOCUS = {
  'Build Six-Pack Abs': ['Abs', 'Cardio', 'Full Body'],
  'Build Chest': ['Chest', 'Arms', 'Full Body'],
  'Gain Muscle': ['Chest', 'Back', 'Legs', 'Arms'],
  'Lose Weight': ['Cardio', 'Full Body', 'Legs'],
  'Full Body Fitness': ['Full Body', 'Legs', 'Chest', 'Back', 'Abs'],
  'Improve Stamina': ['Cardio', 'Full Body', 'Legs'],
  'Stay Healthy': ['Full Body', 'Legs', 'Abs', 'Cardio'],
};

const TIME_MINUTES = {
  '10 Minutes': 10,
  '15 Minutes': 15,
  '20 Minutes': 20,
  '30 Minutes': 30,
  '45 Minutes': 45,
  '60+ Minutes': 60,
};

const TIMELINE_WEEKS = {
  '30 Days': 4,
  '60 Days': 8,
  '90 Days': 12,
  Flexible: 8,
};

const LEVEL_MULT = {
  Beginner: 0.85,
  Intermediate: 1,
  Advanced: 1.2,
};

const ASSESS_MULT = {
  pushups: { '0–5': 0.75, '6–15': 0.95, '16–30': 1.1, '30+': 1.25 },
  plank: { 'Under 15 seconds': 0.8, '15–30 seconds': 1, '30–60 seconds': 1.15, '60+ seconds': 1.3 },
  squats: { '0–10': 0.75, '11–25': 0.95, '26–50': 1.1, '50+': 1.25 },
};

const REST_BY_STYLE = {
  'Fast and Intense': 25,
  Moderate: 40,
  'Slow and Steady': 55,
};

function injurySafe(exercise, injuries = []) {
  const tags = (injuries || []).map((i) => i.toLowerCase());
  const name = `${exercise.name} ${exercise.muscles.join(' ')} ${exercise.category}`.toLowerCase();
  if (tags.some((t) => t.includes('knee')) && /squat|lunge|jump|burpee|high knee/.test(name)) return false;
  if (tags.some((t) => t.includes('shoulder')) && /pike push|pull-up|dip|shoulder tap|handstand/.test(name)) return false;
  if (tags.some((t) => t.includes('back')) && /good morning|superman|jump squat|burpee|hollow/.test(name)) return false;
  return true;
}

function pick(list, n, weekSeed) {
  if (!list.length) return [];
  const out = [];
  const used = new Set();
  for (let i = 0; i < n; i += 1) {
    const idx = (weekSeed * 7 + i * 3) % list.length;
    let chosen = list[idx];
    let guard = 0;
    while (used.has(chosen.id) && guard < list.length) {
      chosen = list[(idx + guard + 1) % list.length];
      guard += 1;
    }
    used.add(chosen.id);
    out.push(chosen);
  }
  return out;
}

function scaleReps(base, level, assessKey, assessment, week) {
  const lm = LEVEL_MULT[level] || 1;
  const am = ASSESS_MULT[assessKey]?.[assessment?.[assessKey === 'pushups' ? 'pushups' : assessKey === 'squats' ? 'squats' : 'plank']] || 1;
  const progressive = 1 + (week - 1) * 0.06;
  return Math.max(5, Math.round(base * lm * am * progressive));
}

function scaleSeconds(base, level, assessment, week) {
  const lm = LEVEL_MULT[level] || 1;
  const am = ASSESS_MULT.plank[assessment?.plank] || 1;
  const progressive = 1 + (week - 1) * 0.08;
  return Math.max(12, Math.round(base * lm * am * progressive));
}

function exerciseCountForTime(minutes) {
  if (minutes <= 10) return 4;
  if (minutes <= 15) return 5;
  if (minutes <= 20) return 6;
  if (minutes <= 30) return 7;
  if (minutes <= 45) return 8;
  return 9;
}

function setsFor(level, week, minutes) {
  const base = level === 'Beginner' ? 2 : level === 'Advanced' ? 3 : 3;
  const extra = week >= 6 ? 1 : 0;
  const timeBoost = minutes >= 45 ? 1 : 0;
  return Math.min(4, base + extra + (minutes >= 30 ? 0 : 0) + timeBoost > 4 ? 4 : base + extra);
}

const DAY_TEMPLATES = {
  'Build Six-Pack Abs': ['Core Blast', 'Cardio Core', 'Active Recovery', 'Abs & Legs', 'Restorative Core', 'HIIT Core', 'Mobility & Walk'],
  'Build Chest': ['Push Power', 'Upper Pump', 'Active Recovery', 'Chest & Arms', 'Light Cardio', 'Push Strength', 'Mobility'],
  'Gain Muscle': ['Push Day', 'Pull Day', 'Leg Day', 'Active Recovery', 'Push Volume', 'Pull Volume', 'Full Body'],
  'Lose Weight': ['Metcon', 'Lower Burn', 'Cardio Intervals', 'Active Recovery', 'Full Body Circuit', 'Cardio Steady', 'Core & Walk'],
  'Full Body Fitness': ['Full Body A', 'Cardio Mix', 'Full Body B', 'Active Recovery', 'Strength Circuit', 'Core & Mobility', 'Full Body C'],
  'Improve Stamina': ['Engine Builder', 'Interval Day', 'Aerobic Base', 'Active Recovery', 'Circuit Endurance', 'Hill-Style Legs', 'Easy Move'],
  'Stay Healthy': ['Move Well', 'Strength Basics', 'Easy Cardio', 'Active Recovery', 'Full Body', 'Core Stability', 'Walk & Stretch'],
};

export function generatePlan(profile) {
  const minutes = TIME_MINUTES[profile.dailyTime] || 20;
  const weeks = TIMELINE_WEEKS[profile.timeline] || 8;
  const focus = GOAL_FOCUS[profile.goal] || GOAL_FOCUS['Full Body Fitness'];
  const available = profile.equipment?.length ? profile.equipment : [EQUIPMENT.NONE];
  const pool = filterByEquipment(EXERCISES, available).filter((ex) => injurySafe(ex, profile.injuries));
  const safePool = pool.length ? pool : EXERCISES.filter((e) => e.equipment.includes(EQUIPMENT.NONE));
  const rest = REST_BY_STYLE[profile.style] || 40;
  const count = exerciseCountForTime(minutes);
  const titles = DAY_TEMPLATES[profile.goal] || DAY_TEMPLATES['Stay Healthy'];

  const planWeeks = [];
  for (let w = 1; w <= weeks; w += 1) {
    const days = [];
    for (let d = 1; d <= 7; d += 1) {
      const isRecovery = d === 4 || titles[d - 1]?.toLowerCase().includes('mobility') || titles[d - 1]?.toLowerCase().includes('restorative');
      const focusCat = focus[(d + w) % focus.length];
      let candidates = safePool.filter((e) => e.category === focusCat || e.category === 'Full Body');
      if (isRecovery) {
        candidates = safePool.filter((e) => e.difficulty !== 'Advanced' && !['burpee', 'jump-squat'].includes(e.id));
      }
      if (candidates.length < 3) candidates = safePool;
      const selected = pick(candidates, isRecovery ? Math.max(3, count - 2) : count, w * 10 + d);
      const sets = isRecovery ? 2 : setsFor(profile.level, w, minutes);
      const exercises = selected.map((ex) => {
        const assessKey = ex.category === 'Chest' || ex.category === 'Arms' ? 'pushups' : ex.category === 'Legs' ? 'squats' : 'plank';
        if (ex.timed) {
          return {
            id: ex.id,
            name: ex.name,
            category: ex.category,
            timed: true,
            sets,
            seconds: scaleSeconds(ex.baseSeconds || 20, profile.level, profile.assessment, w),
            rest,
          };
        }
        return {
          id: ex.id,
          name: ex.name,
          category: ex.category,
          timed: false,
          sets,
          reps: scaleReps(ex.baseReps || 10, profile.level, assessKey, profile.assessment, w),
          rest,
        };
      });
      days.push({
        id: `w${w}-d${d}`,
        week: w,
        day: d,
        title: titles[d - 1] || `Day ${d}`,
        focus: isRecovery ? 'Recovery' : focusCat,
        duration: isRecovery ? Math.max(10, minutes - 5) : minutes,
        completed: false,
        exercises,
      });
    }
    planWeeks.push({ week: w, days });
  }

  return {
    createdAt: new Date().toISOString(),
    goal: profile.goal,
    timeline: profile.timeline,
    weeks: planWeeks,
  };
}

export function flattenDays(plan) {
  if (!plan?.weeks) return [];
  return plan.weeks.flatMap((w) => w.days);
}

export function getDayById(plan, id) {
  return flattenDays(plan).find((d) => d.id === id);
}

export { getExercise };
